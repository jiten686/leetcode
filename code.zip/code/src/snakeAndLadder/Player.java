package snakeAndLadder;

public class Player {

	String id;
	int currentPos;

	public Player(String id, int currentPos) {

		this.id = id;
		this.currentPos = currentPos;
	}
	
	
	// getter and setter

}
