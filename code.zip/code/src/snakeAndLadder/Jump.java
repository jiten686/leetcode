package snakeAndLadder;

public class Jump {
	// used for both ladder and snake 
	int start;
	int end;
	
	// getter & setter

}
