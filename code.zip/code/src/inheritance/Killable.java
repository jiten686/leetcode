package inheritance;

public interface Killable {
	public void print();
	
	public static void printName() {
		System.out.println("My name is kill box one alpha");
	}
}
