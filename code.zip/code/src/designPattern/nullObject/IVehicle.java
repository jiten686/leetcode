package designPattern.nullObject;

public interface IVehicle {
	int getSeatingCapacity();

	int getMileage();
}
