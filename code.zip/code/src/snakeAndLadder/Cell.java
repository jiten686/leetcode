package snakeAndLadder;

public class Cell {
	
	Jump jump;

}
