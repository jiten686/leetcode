package designPattern.decorativePattern;

public abstract class DecorativeBurger extends Burger{

}
