package ticTacToe;

public class PlayingPieceO extends PlayingPiece {

	public PlayingPieceO(PieceType pieceType) {
		super(pieceType);
	}

}
