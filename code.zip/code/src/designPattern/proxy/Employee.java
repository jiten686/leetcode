package designPattern.proxy;

public class Employee {

}
