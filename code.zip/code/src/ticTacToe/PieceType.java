package ticTacToe;

public enum PieceType {

	X, O;

}
