package ticTacToe;

public class PlayingPieceX extends PlayingPiece{

	public PlayingPieceX(PieceType pieceType) {
		super(pieceType);
	}

}
