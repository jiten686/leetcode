package ticTacToe;

public class PlayingPiece {

	PieceType pieceType;

	public PlayingPiece(PieceType pieceType) {
		this.pieceType = pieceType;
	}

}
