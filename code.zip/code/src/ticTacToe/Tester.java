package ticTacToe;

public class Tester {

	public static void main(String[] args) {
		TicTacToeGame game = new TicTacToeGame();
		System.out.println("Winner is : "+ game.startGame());

	}

}
