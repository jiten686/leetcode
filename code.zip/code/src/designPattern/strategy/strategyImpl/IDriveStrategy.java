package designPattern.strategy.strategyImpl;

public interface IDriveStrategy {
	
	void drive();

}
